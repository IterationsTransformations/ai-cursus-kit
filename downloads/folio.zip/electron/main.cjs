// Folio desktop shell: one window, PDFs (and Word documents, converted) opened from Explorer / "Open with",
// files served over app://.
const { app, BrowserWindow, protocol, net, ipcMain, dialog, shell, screen, session } = require("electron");
const crypto = require("node:crypto");
const path = require("node:path");
const fs = require("node:fs");
const { pathToFileURL } = require("node:url");
const { autoUpdater } = require("electron-updater");
const ai = require("./ai.cjs");
const { captureWebpage } = require("./webpage.cjs");
const { guardSession, resolveDestination } = require("./network.cjs");
const { safePdfName } = require("./filenames.cjs");
const { csp } = require("./csp.cjs");
const { WORD_FILE, openWord } = require("./convert.cjs");
const { registerPrinting } = require("./printing.cjs");
const { MAX_DOCUMENT_BYTES, checkDiskPath, readRegular } = require("./document-files.cjs");

if (!app.isPackaged && process.env.FOLIO_TEST_USER_DATA) app.setPath("userData", process.env.FOLIO_TEST_USER_DATA);
// Automated tests drive a window that never appears, so a local run doesn't take over the screen or focus.
const TEST_HIDDEN = !app.isPackaged && process.env.FOLIO_TEST_HIDDEN === "1";
// macOS gives every ordinary app a Dock icon, whatever its windows do. An accessory app has none and can't come
// forward by itself. The test scripts start a copy of Electron that is one from its first moment
// (scripts/electron-path.mjs); this covers a hidden launch of the ordinary Electron, set right away because the Dock
// starts making room for the icon as soon as the app starts.
if (TEST_HIDDEN && process.platform === "darwin") app.setActivationPolicy("accessory");

const DIST = path.join(__dirname, "..", "dist");
// Development only (e.g. http://localhost:5173); ignored by installed builds.
const DEV_URL = !app.isPackaged && process.env.FOLIO_DEV_URL ? new URL(process.env.FOLIO_DEV_URL).origin : null;
const isAppUrl = (url) => {
  try { return url.startsWith("app://folio/") || (!!DEV_URL && new URL(url).origin === DEV_URL); } catch { return false; }
};

// Sent as a response header on app:// (see csp.cjs). The page never needs the network here: PDFs are
// read from disk, and "Open a link" downloads happen in this process.
const CSP = csp({ connect: "'self' data: blob:" });

function isTrustedSender(event) {
  if (!win || event.sender !== win.webContents) return false;
  const url = event.senderFrame?.url ?? "";
  return isAppUrl(url);
}

// Title bar colours follow the app theme (see src/styles.css --bg). Height is one pixel short of
// --topbar-h so the toolbar's bottom border runs underneath the window controls.
const TITLEBAR = {
  dark: { color: "#171717", symbolColor: "#edece9", height: 51 },
  light: { color: "#f5f4f1", symbolColor: "#1c1b19", height: 51 },
};

const IS_MAC = process.platform === "darwin";
const IS_LINUX = process.platform === "linux";
const RELEASES_PAGE = "https://github.com/Forward-Future/folio-releases/releases/latest";

protocol.registerSchemesAsPrivileged([
  { scheme: "app", privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true } },
]);

let win = null;
const OPENABLE = /\.(pdf|docx?)$/i;
const pendingFiles = filesFromArgs(process.argv);
let rendererReady = false;

// macOS hands files to the app through "open-file" (Finder, the Dock, "Open With") rather than argv.
// It can fire before the app is ready, so register it right away.
app.on("open-file", (event, file) => {
  event.preventDefault();
  if (!OPENABLE.test(file)) return;
  if (win && rendererReady) {
    if (!TEST_HIDDEN) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
    void sendFile(file);
  } else {
    pendingFiles.push(file);
    if (app.isReady() && !win) createWindow();
  }
});

function filesFromArgs(argv, cwd = process.cwd()) {
  return argv.slice(1).filter(a => !a.startsWith("-") && OPENABLE.test(a))
    .map(file => path.resolve(cwd, file)).filter(file => fs.existsSync(file));
}

// The read is async and size-capped like URL downloads: a huge file or a slow network
// share shouldn't freeze the main process or balloon memory in two processes.
async function sendFiles(files) {
  for (const file of files) await sendFile(file);
}

async function sendFile(file) {
  const target = win;
  if (!file || !target) return;
  if (WORD_FILE.test(file)) return sendWordFile(file, target);
  try {
    checkDiskPath(file);
    const data = await readRegular(await fs.promises.realpath(file));
    if (!target.isDestroyed()) target.webContents.send("folio:open-file", { name: path.basename(file), data });
  } catch (err) {
    dialog.showErrorBox("Couldn't open file", `${file}\n\n${err.userMessage ?? err.message}`);
  }
}

// A Word document opens as a PDF, saved next to it ("Report.docx" gets "Report.pdf") so it's there to share
// afterwards. A folder Folio can't write to (a read-only share) just means the PDF isn't kept.
async function sendWordFile(file, target) {
  const send = (channel, payload) => { if (!target.isDestroyed()) target.webContents.send(channel, payload); };
  const original = path.basename(file);
  const token = crypto.randomUUID();
  send("folio:converting", { name: original, token });
  try {
    send("folio:open-file", { ...await openWord(file, (msg) => logConvert(`${file}: ${msg}`)), token });
  } catch (error) {
    logConvert(`${file}: ${error?.stack || error}`);
    send("folio:open-failed", { token, message: `Couldn't convert “${original}” to PDF. ${error?.userMessage ?? ""}`.trim() });
  }
}

function logConvert(msg) {
  try {
    fs.appendFileSync(path.join(app.getPath("userData"), "convert.log"), `${new Date().toISOString()} ${msg}\n`);
  } catch {}
}

// ── Auto-update ──────────────────────────────────────────────────────
// Installed copies check GitHub Releases (Forward-Future/folio-releases, see "publish" in package.json)
// on launch and every few hours, download new versions in the background, and install them on quit
// or when the user clicks "Restart" in the update banner. Progress is shown on the home screen and
// logged to update.log in the app's user-data folder.
let updateReady = null;
let updateStatus = { state: "idle" };
let updatesEnabled = false;
let automaticUpdates = true;
let activeUpdate = null;
const UPDATE_INTERVAL_MS = 4 * 60 * 60 * 1000;

function loadUpdatePreference() {
  try {
    automaticUpdates = JSON.parse(fs.readFileSync(path.join(app.getPath("userData"), "update-settings.json"), "utf8")).enabled !== false;
  } catch { automaticUpdates = true; }
}

function saveUpdatePreference(enabled) {
  if (typeof enabled !== "boolean") throw new Error("Invalid auto-update preference");
  const filename = path.join(app.getPath("userData"), "update-settings.json");
  fs.writeFileSync(filename + ".tmp", JSON.stringify({ enabled }));
  fs.renameSync(filename + ".tmp", filename);
  automaticUpdates = enabled;
  autoUpdater.autoInstallOnAppQuit = enabled;
  if (!enabled && activeUpdate && !activeUpdate.manual) activeUpdate.token?.cancel();
  if (enabled) void checkForUpdates();
  return enabled;
}

function logUpdate(msg) {
  try {
    fs.appendFileSync(path.join(app.getPath("userData"), "update.log"), `${new Date().toISOString()} ${msg}\n`);
  } catch {}
}

function setUpdateStatus(status) {
  updateStatus = status;
  win?.webContents.send("folio:update-status-changed", status);
}

async function checkForUpdates(manual = false) {
  // Keep the reason (e.g. "system" for apt-managed copies) when a manual check finds updates unsupported.
  if (!updatesEnabled) return setUpdateStatus(updateStatus.state === "unsupported" ? updateStatus : { state: "unsupported" });
  if ((!manual && !automaticUpdates) || updateReady || activeUpdate) return;
  const operation = { manual, token: null };
  activeUpdate = operation;
  try {
    const result = await autoUpdater.checkForUpdates();
    if (result?.isUpdateAvailable && NOTIFY_ONLY) {
      setUpdateStatus({ state: "available", version: result.updateInfo.version });
    } else if (result?.isUpdateAvailable && (manual || automaticUpdates)) {
      operation.token = result.cancellationToken;
      setUpdateStatus({ state: "downloading", version: result.updateInfo.version, percent: 0 });
      await autoUpdater.downloadUpdate(result.cancellationToken);
      if (operation.token?.cancelled && !updateReady) setUpdateStatus({ state: "idle" });
    } else if (result?.isUpdateAvailable) setUpdateStatus({ state: "idle" });
  } catch (error) {
    if (operation.token?.cancelled) setUpdateStatus({ state: "idle" });
    else setUpdateStatus({ state: "error", message: String(error?.message || error).split("\n")[0] });
  } finally { activeUpdate = null; }
}

/** How this copy was installed, which decides how it can be updated. */
function installKind() {
  if (!app.isPackaged) return "development";
  if (process.env.PORTABLE_EXECUTABLE_FILE) return "portable";
  if (IS_LINUX) return process.env.APPIMAGE ? "appimage" : "package";
  return "installed";
}

function installLocation() {
  if (process.env.PORTABLE_EXECUTABLE_FILE || process.env.APPIMAGE) {
    return path.dirname(process.env.PORTABLE_EXECUTABLE_FILE || process.env.APPIMAGE);
  }
  const exeDir = path.dirname(app.getPath("exe"));
  // Inside a packaged .app the exe lives in Contents/MacOS; the install folder is where the .app sits.
  return IS_MAC && /\.app[\/\\]Contents[\/\\]MacOS$/.test(exeDir) ? path.resolve(exeDir, "..", "..", "..") : exeDir;
}

// macOS only installs updates signed with an Apple Developer ID. Release builds made with the Developer ID
// certificate set folioMacSigned (see .github/workflows/release-build.yml); other Mac builds are told about
// new versions and download them from the releases page.
const MAC_SIGNED = !!require("../package.json").folioMacSigned;
const NOTIFY_ONLY = IS_MAC && !MAC_SIGNED;

function setupAutoUpdate() {
  loadUpdatePreference();
  // Installed Windows builds, Linux AppImages, and Macs check for updates. Dev runs and the portable Windows exe
  // don't; Linux packages (.deb) are updated by apt along with the rest of the system.
  // FOLIO_UPDATE_TEST lets the unpacked build be tested.
  const kind = installKind();
  if (kind === "package") {
    updateStatus = { state: "unsupported", message: "system" };
    return;
  }
  if ((kind === "development" && !process.env.FOLIO_UPDATE_TEST) || kind === "portable") {
    updateStatus = { state: "unsupported" };
    return;
  }
  updatesEnabled = true;
  if (!app.isPackaged) autoUpdater.forceDevUpdateConfig = true; // reads dev-app-update.yml
  autoUpdater.autoDownload = false;
  autoUpdater.autoInstallOnAppQuit = automaticUpdates;
  autoUpdater.logger = { info: logUpdate, warn: logUpdate, error: logUpdate, debug() {} };
  autoUpdater.on("checking-for-update", () => setUpdateStatus({ state: "checking" }));
  autoUpdater.on("update-not-available", () => setUpdateStatus({ state: "latest", checkedAt: Date.now() }));
  autoUpdater.on("download-progress", (p) =>
    setUpdateStatus({ state: "downloading", version: updateStatus.version, percent: Math.round(p.percent) }),
  );
  autoUpdater.on("update-downloaded", (info) => {
    updateReady = info.version;
    setUpdateStatus({ state: "ready", version: info.version });
  });
  autoUpdater.on("error", (err) => {
    logUpdate(`error: ${err?.stack || err}`);
    setUpdateStatus({ state: "error", message: String(err?.message || err).split("\n")[0] });
  });
  logUpdate(`Folio ${app.getVersion()} (${process.arch}) starting update checks`);
  checkForUpdates();
  setInterval(() => void checkForUpdates(), UPDATE_INTERVAL_MS);
}

function createWindow() {
  let savedWindow = null;
  const windowStatePath = path.join(app.getPath("userData"), "window-state.json");
  try {
    const saved = JSON.parse(fs.readFileSync(windowStatePath, "utf8"));
    const bounds = saved.bounds;
    if (bounds && [bounds.x, bounds.y, bounds.width, bounds.height].every(Number.isFinite) && bounds.width >= 600 && bounds.height >= 400) {
      const area = screen.getDisplayMatching(bounds).workArea;
      savedWindow = { bounds: { width: Math.min(bounds.width, area.width), height: Math.min(bounds.height, area.height),
        x: Math.max(area.x, Math.min(bounds.x, area.x + area.width - Math.min(bounds.width, area.width))),
        y: Math.max(area.y, Math.min(bounds.y, area.y + area.height - Math.min(bounds.height, area.height))) }, maximized: saved.maximized === true };
    }
  } catch {}
  const theme = "dark"; // the page reports its real theme on load via folio:theme
  win = new BrowserWindow({
    width: 1360,
    height: 900,
    ...(savedWindow?.bounds ?? {}),
    minWidth: 420,
    minHeight: 480,
    show: false,
    backgroundColor: TITLEBAR[theme].color,
    title: "Folio",
    icon: path.join(__dirname, "icon.png"),
    titleBarStyle: "hidden",
    // macOS keeps its traffic lights (inset into the top bar); Windows and Linux draw their window
    // buttons as an overlay on the right.
    ...(IS_MAC ? { trafficLightPosition: { x: 18, y: 18 } } : { titleBarOverlay: TITLEBAR[theme] }),
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      sandbox: true,
      plugins: true, // Chromium's PDF viewer, used for printing
      // A hidden window is throttled like a background tab; tests need it to render at full speed.
      ...(TEST_HIDDEN ? { backgroundThrottling: false } : {}),
    },
  });

  const cameraOwner = win.webContents;
  const trustedCameraOrigin = isAppUrl;
  // Folio's own page may write (never read) the clipboard, for its Copy buttons.
  const clipboardWrite = (contents, permission, url) =>
    contents === cameraOwner && permission === "clipboard-sanitized-write" && isAppUrl(url ?? "");
  cameraOwner.session.setPermissionCheckHandler((contents, permission, origin, details) =>
    contents === cameraOwner && permission === "media" && trustedCameraOrigin(details.requestingUrl || origin) && details.mediaType === "video");
  cameraOwner.session.setPermissionRequestHandler((contents, permission, callback, details) => {
    if (clipboardWrite(contents, permission, details.requestingUrl)) return callback(true);
    if (contents !== cameraOwner || permission !== "media" || !details.isMainFrame
      || !trustedCameraOrigin(details.requestingUrl) || !details.mediaTypes?.length
      || details.mediaTypes.some(type => type !== "video")) return callback(false);
    dialog.showMessageBox(win, { type: "question", title: "Use camera for signature?", message: "Allow Folio to use your camera to capture a signature?",
      detail: "Camera images are processed on this device. No microphone is requested.", buttons: ["Allow camera", "Cancel"], defaultId: 1, cancelId: 1 })
      .then(result => callback(result.response === 0)).catch(() => callback(false));
  });

  win.once("ready-to-show", () => {
    if (TEST_HIDDEN) {
      // macOS moves a window back onto the screen as it is shown, wherever it was put. A window that is never
      // shown still paints there (Electron starts it in Chromium's headless mode), so tests can leave it unshown.
      if (IS_MAC) return;
      // Elsewhere a never-shown window doesn't paint, so tests couldn't screenshot it. Show it off-screen instead,
      // without taking focus or adding a taskbar button.
      win.setSkipTaskbar(true);
      win.setPosition(-32000, -32000);
      win.showInactive();
      return;
    }
    if (savedWindow?.maximized) win.maximize();
    win.show();
  });
  const saveWindow = () => {
    if (!win || win.isDestroyed() || win.isMinimized() || win.isFullScreen()) return;
    try {
      fs.writeFileSync(windowStatePath, JSON.stringify({ bounds: win.getNormalBounds(), maximized: win.isMaximized() }));
    } catch {}
  };
  let windowTimer;
  const scheduleWindowSave = () => { clearTimeout(windowTimer); windowTimer = setTimeout(saveWindow, 300); };
  win.on("resize", scheduleWindowSave);
  win.on("move", scheduleWindowSave);
  win.on("close", saveWindow);
  // Native menu accelerators (especially Cmd+W on macOS) run before a DOM keydown.
  win.webContents.on("before-input-event", (event, input) => {
    if (input.type !== "keyDown" || input.alt) return;
    let command;
    if (input.control && input.key === "Tab") command = input.shift ? "previous" : "next";
    else if (!input.shift && (IS_MAC ? input.meta : input.control)) {
      if (input.key.toLowerCase() === "t") command = "new";
      if (input.key.toLowerCase() === "w") command = "close";
    }
    if (command) { event.preventDefault(); win.webContents.send("folio:tab-command", command); }
  });
  win.loadURL(DEV_URL ? DEV_URL + "/" : "app://folio/index.html");

  // Links inside PDFs open in the default browser, never in-app (see openLink).
  win.webContents.setWindowOpenHandler(({ url }) => {
    void openLink(url);
    return { action: "deny" };
  });
  // Subframes (the print frame) may only show Folio pages, local blob: PDFs, and Chromium's built-in PDF viewer.
  const PDF_VIEWER = "chrome-extension://mhjfbmdgcfjbbpaeojofohoefgiehjai/";
  win.webContents.on("will-frame-navigate", (e) => {
    const allowed = isAppUrl(e.url) || e.url.startsWith("blob:app://folio/") || e.url.startsWith(PDF_VIEWER) || e.url === "about:blank";
    if (!e.isMainFrame && !allowed) e.preventDefault();
  });
  win.webContents.on("will-navigate", (e, url) => {
    if (!isAppUrl(url)) {
      e.preventDefault();
      if (/^https?:/.test(url)) void openLink(url);
    }
  });

  // The page blocks unload while annotations are unsaved; ask instead of silently refusing to close.
  win.webContents.on("will-prevent-unload", (e) => {
    const choice = dialog.showMessageBoxSync(win, {
      type: "question",
      buttons: ["Close without saving", "Cancel"],
      defaultId: 1,
      cancelId: 1,
      title: "Unsaved changes",
      message: "One or more tabs have unsaved changes.",
      detail: `Press ${IS_MAC ? "⌘S" : "Ctrl+S"} in each marked tab to save a copy before closing Folio.`,
    });
    if (choice === 0) e.preventDefault();
  });

  win.on("closed", () => { clearTimeout(windowTimer); win = null; rendererReady = false; });
}

const MAX_URL_PDF_BYTES = MAX_DOCUMENT_BYTES;

// Shown in dialogs: long enough to see where a link goes, short enough that the dialog stays readable.
const shortUrl = (url) => (url.href.length > 300 ? url.href.slice(0, 300) + "…" : url.href);

// Folio's own links (src/ai.ts) open without asking.
const FOLIO_LINKS = new Set(["https://chatgpt.com/settings/usage", "https://claude.com/claude-code"]);
let askingAboutLink = false;

// Links open in the browser (mailto: in the mail app), never in Folio, and only once the user has seen where they go:
// a PDF decides both a link's address and its clickable area, which can be invisible and cover the whole page.
async function openLink(rawUrl) {
  let url;
  try { url = new URL(rawUrl); } catch { return; }
  if (url.protocol !== "http:" && url.protocol !== "https:" && url.protocol !== "mailto:") return;
  if (!FOLIO_LINKS.has(url.href)) {
    if (askingAboutLink || !win) return; // one question at a time
    askingAboutLink = true;
    const mail = url.protocol === "mailto:";
    const { response } = await dialog.showMessageBox(win, {
      type: "question",
      title: "Open link?",
      message: mail ? "Open this email link in your mail app?" : `Open ${url.host} in your browser?`,
      detail: shortUrl(url),
      buttons: [mail ? "Open mail app" : "Open link", "Cancel"],
      defaultId: 0,
      cancelId: 1,
    }).finally(() => { askingAboutLink = false; });
    if (response !== 0) return;
  }
  await shell.openExternal(url.href);
}

// Asked before Folio opens an address on this computer or the local network, here rather than in the page: a document
// that managed to run code in the page could otherwise use Folio to reach them.
async function confirmLocalAddress(url, addresses, signal) {
  const { response } = await dialog.showMessageBox(win, {
    signal, // closing the tab that asked dismisses the question, as if Cancel was chosen
    type: "warning",
    title: "Open a local address?",
    message: `Open ${url.host}?`,
    detail: `Allow ${url.origin} to connect to the following resolved addresses?\n\n${addresses.join(", ")}\n\n${shortUrl(url)}`,
    buttons: ["Open", "Cancel"],
    defaultId: 1,
    cancelId: 1,
  });
  return response === 0;
}

// The name a download gets: from Content-Disposition when the server sends one, else the URL's last segment.
function pdfNameFromResponse(url, disposition) {
  const match = /filename\*=(?:UTF-8'')?([^;]+)|filename="?([^";]+)"?/i.exec(disposition || "");
  let name = (match?.[1] || match?.[2] || "").trim();
  try { name = decodeURIComponent(name || url.pathname.split("/").filter(Boolean).pop() || ""); } catch {}
  return safePdfName(name, url.hostname);
}

// Desktop PDF downloads use the same pinned network policy as webpage capture.
// Resolves to { name, data } or { error } (error text is shown to the user as-is), or to { cancelled: true }
// once `signal` aborts.
async function downloadPdf(url, approvedLocal, signal) {
  const ses = session.fromPartition(`folio-download-${crypto.randomUUID()}`); // in-memory only
  const guard = await guardSession(ses, session.defaultSession, approvedLocal, app);
  if (signal.aborted) {
    guard.close();
    return { cancelled: true };
  }
  return new Promise((resolve) => {
    let done = false;
    const request = net.request({ url: url.toString(), redirect: "manual", session: ses, cache: "no-store" });
    const finish = (result) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      if (result.error || result.webpage) request.abort();
      resolve(result);
    };
    // The minute is for a silent connection, not for the whole file: a large PDF on a slow connection keeps
    // going for as long as data arrives.
    let timer;
    const alive = () => {
      clearTimeout(timer);
      if (!done) timer = setTimeout(() => finish({ error: "The download timed out." }), 60_000);
    };
    alive();
    request.on("redirect", alive);
    request.on("response", (response) => { alive(); response.on("data", alive); });
    signal.addEventListener("abort", () => { finish({ cancelled: true }); request.abort(); }, { once: true });
    let hops = 0;
    request.setHeader("Accept", "application/pdf,*/*;q=0.8");
    // Track redirects ourselves: the final address usually carries the real file name.
    request.on("redirect", (_status, _method, redirectUrl) => {
      const next = new URL(redirectUrl, url);
      if (++hops > 10) return finish({ error: "That link redirects too many times." });
      if (next.protocol !== "http:" && next.protocol !== "https:") return finish({ error: "That link redirects somewhere Folio can't open." });
      url = next;
      request.followRedirect();
    });
    request.on("error", () => finish({ error: guard.refusedLocal()
      ? "That link leads to a local network address, so Folio didn't follow it." : `Couldn't reach ${url.hostname}.` }));
    request.on("response", (response) => {
      if (response.statusCode < 200 || response.statusCode >= 300) {
        return finish({ error: `The server responded with ${response.statusCode}${response.statusMessage ? " " + response.statusMessage : ""}.` });
      }
      const header = (key) => [].concat(response.headers[key] ?? [])[0];
      // A webpage: stop downloading and let the caller render it to PDF instead.
      if (/\b(text\/html|application\/xhtml\+xml)\b/i.test(header("content-type") ?? "")) {
        return finish({ webpage: url.toString() });
      }
      const tooBig = { error: "That PDF is larger than 300 MB." };
      if (Number(header("content-length")) > MAX_URL_PDF_BYTES) return finish(tooBig);
      const chunks = [];
      let size = 0;
      let verifiedHeader = false;
      const checkHeader = (head) => {
        if (head.subarray(0, 1024).indexOf("%PDF-") >= 0) return true;
        // Some servers don't label HTML; recognize it by its start.
        if (/^\s*(<!doctype html|<html|<head|<body)/i.test(head.subarray(0, 512).toString("latin1"))) {
          finish({ webpage: url.toString() });
        } else {
          finish({ error: "That link isn't a PDF or a webpage." });
        }
        return false;
      };
      response.on("data", (chunk) => {
        if (done) return;
        size += chunk.byteLength;
        if (size > MAX_URL_PDF_BYTES) return finish(tooBig);
        chunks.push(chunk);
        if (!verifiedHeader && size >= 1024) {
          verifiedHeader = true;
          checkHeader(Buffer.concat(chunks, 1024));
        }
      });
      response.on("error", () => finish({ error: "The download was interrupted." }));
      response.on("end", () => {
        if (done) return;
        const data = Buffer.concat(chunks);
        if (!verifiedHeader && !checkHeader(data)) return;
        finish({ name: pdfNameFromResponse(url, header("content-disposition")), data });
      });
    });
    request.end();
  }).finally(guard.close);
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  // A second launch (e.g. double-clicking another PDF) hands its file to the running window.
  app.on("second-instance", (_e, argv, cwd) => {
    const files = filesFromArgs(argv, cwd);
    if (!win || !rendererReady) {
      pendingFiles.push(...files);
      if (!win && app.isReady()) createWindow();
      return;
    }
    if (!TEST_HIDDEN) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
    void sendFiles(files);
  });

  app.whenReady().then(() => {
    protocol.handle("app", async (req) => {
      const { host, pathname } = new URL(req.url);
      if (host !== "folio") return new Response("Not found", { status: 404 });
      let file;
      try { file = path.normalize(path.join(DIST, decodeURIComponent(pathname))); } catch { return new Response("Bad request", { status: 400 }); }
      if (!file.startsWith(DIST + path.sep)) return new Response("Forbidden", { status: 403 });
      const response = await net.fetch(pathToFileURL(file).toString());
      const headers = new Headers(response.headers);
      headers.set("Content-Security-Policy", CSP);
      return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
    });

    // Only Folio's own page may call into the main process.
    const handle = (channel, listener) => ipcMain.handle(channel, (event, ...args) => {
      if (!isTrustedSender(event)) throw new Error("Untrusted sender");
      return listener(event, ...args);
    });
    const on = (channel, listener) => ipcMain.on(channel, (event, ...args) => {
      if (isTrustedSender(event)) listener(event, ...args);
    });

    ai.register(handle, (channel, payload) => win?.webContents.send(channel, payload), { confirmLocal: (url, addresses) => confirmLocalAddress(url, addresses) });
    registerPrinting(handle, () => win);

    handle("folio:ready", () => {
      rendererReady = true;
      const files = pendingFiles.splice(0);
      if (files.length) setTimeout(() => void sendFiles(files), 0);
      return files.length > 0;
    });
    // Word documents picked or dropped in Folio (PDFs are read by the page itself).
    handle("folio:open-document", (_event, file) => {
      if (typeof file !== "string" || !WORD_FILE.test(file) || !path.isAbsolute(file)) throw new Error("Not a Word document");
      return openWord(file, (msg) => logConvert(`${file}: ${msg}`));
    });
    // PDF links open directly; webpages are converted to a PDF first. An address on this computer or the local
    // network opens only once the user agrees (cancelling resolves to { cancelled: true }).
    // One link opens at a time. The page names its request so it can stop it (a closed tab, another document
    // opened instead): an abandoned link would otherwise keep every other one waiting until it timed out.
    let importing = null;
    handle("folio:fetch-pdf", async (_event, rawUrl, id) => {
      let url;
      try { url = new URL(typeof rawUrl === "string" && rawUrl.length <= 8192 ? rawUrl.trim() : ""); }
      catch { return { error: "That isn't a valid web address." }; }
      if (url.protocol !== "http:" && url.protocol !== "https:") return { error: "Only http:// and https:// links can be opened." };
      if (importing) return { error: "Another link is still opening." };
      const controller = new AbortController();
      const { signal } = controller;
      importing = { id: typeof id === "string" ? id : "", controller };
      try {
        const destination = await resolveDestination(url, session.defaultSession);
        if (signal.aborted) return { cancelled: true };
        if (destination.local && !(await confirmLocalAddress(url, destination.addresses, signal))) return { cancelled: true };
        const approved = destination.local ? destination : null;
        const result = await downloadPdf(url, approved, signal);
        if (!result.webpage) return result;
        return await captureWebpage(result.webpage, approved?.origin === new URL(result.webpage).origin ? approved : null, signal);
      } catch {
        return signal.aborted ? { cancelled: true } : { error: `Couldn't open a verified connection to ${url.hostname}.` };
      } finally { importing = null; }
    });
    handle("folio:cancel-fetch-pdf", (_event, id) => {
      if (importing?.id && importing.id === id) importing.controller.abort();
      return true;
    });
    handle("folio:app-info", () => ({ version: app.getVersion(), mode: installKind(), location: installLocation(), platform: process.platform,
      notifyOnly: NOTIFY_ONLY }));
    handle("folio:open-installation", () => shell.openPath(installLocation()));
    handle("folio:open-download", () => shell.openExternal(RELEASES_PAGE));
    handle("folio:download-ocr-model", async (_event, code) => {
      const { downloadOcrModel } = await import("./ocr-download.mjs");
      return downloadOcrModel(code, (url, options) => net.fetch(url, options));
    });
    handle("folio:update-state", () => updateStatus);
    handle("folio:auto-update-setting", () => automaticUpdates);
    handle("folio:set-auto-update-setting", (_event, enabled) => saveUpdatePreference(enabled));
    on("folio:check-update", () => void checkForUpdates(true));
    on("folio:install-update", () => {
      if (updateReady) autoUpdater.quitAndInstall(true, true);
    });
    on("folio:theme", (_e, theme) => {
      if (win && Object.hasOwn(TITLEBAR, theme)) {
        if (!IS_MAC) win.setTitleBarOverlay(TITLEBAR[theme]);
        win.setBackgroundColor(TITLEBAR[theme].color);
      }
    });

    createWindow();
    setupAutoUpdate();
  });

  // macOS apps stay running with no windows; clicking the Dock icon opens a new one.
  app.on("window-all-closed", () => { if (!IS_MAC) app.quit(); });
  app.on("activate", () => { if (app.isReady() && !win) createWindow(); });
}
